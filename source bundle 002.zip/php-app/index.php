<h1>Hello World!!!</h1>
<h2>This is multi-container Docker on AWS Elastic Beanstalk - environment.</h2>
<h3>PHP Version <pre><?= phpversion() ?></pre></h3>

<a href="https://itachi-p.com">いたちホームに戻る</a>
